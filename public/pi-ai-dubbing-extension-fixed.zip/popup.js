/**
 * Pi AI Dubbing - Extension Popup Controller
 * Connects directly to background service worker and displays real-time dubbing status,
 * tab target info, latency metrics, and controls.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const elBackendBadge = document.getElementById('connection-badge');
  const elBackendStatusText = document.getElementById('backend-status-text');
  const elValBrowser = document.getElementById('val-browser');
  const elValBackend = document.getElementById('val-backend');
  const elValTarget = document.getElementById('val-target');
  const elValCapture = document.getElementById('val-capture');
  const elValStt = document.getElementById('val-stt');
  const elValTranslation = document.getElementById('val-translation');
  const elValVoice = document.getElementById('val-voice');
  const elValLatency = document.getElementById('val-latency');

  const elSegmentBadge = document.getElementById('segment-badge');
  const elLiveSourceText = document.getElementById('live-source-text');
  const elLiveArabicText = document.getElementById('live-arabic-text');

  const btnStart = document.getElementById('btn-start');
  const btnStop = document.getElementById('btn-stop');
  const btnPause = document.getElementById('btn-pause');
  const btnResume = document.getElementById('btn-resume');
  const btnReconnect = document.getElementById('btn-reconnect');

  const errorBanner = document.getElementById('error-banner');
  const errorBannerText = document.getElementById('error-banner-text');
  const errorBannerClose = document.getElementById('error-banner-close');

  const diagExt = document.getElementById('diag-ext');
  const diagManifest = document.getElementById('diag-manifest');
  const diagSw = document.getElementById('diag-sw');
  const diagPopup = document.getElementById('diag-popup');
  const diagBackend = document.getElementById('diag-backend');
  const diagContent = document.getElementById('diag-content');
  const diagOffscreen = document.getElementById('diag-offscreen');
  const diagCapture = document.getElementById('diag-capture');
  const diagErrors = document.getElementById('diag-errors');
  const diagErrorsBadge = document.getElementById('diag-errors-badge');

  function showError(msg) {
    if (errorBanner && errorBannerText) {
      errorBannerText.textContent = msg;
      errorBanner.style.display = 'flex';
    }
    if (diagErrors) {
      diagErrors.textContent = msg.slice(0, 50);
      diagErrors.className = 'diag-val text-rose';
    }
    if (diagErrorsBadge) {
      diagErrorsBadge.textContent = '1 Error';
      diagErrorsBadge.className = 'badge-err';
    }
  }

  function clearError() {
    if (errorBanner) errorBanner.style.display = 'none';
    if (diagErrors) {
      diagErrors.textContent = '0 (لا توجد أخطاء)';
      diagErrors.className = 'diag-val text-emerald';
    }
    if (diagErrorsBadge) {
      diagErrorsBadge.textContent = '0 Errors';
      diagErrorsBadge.className = 'badge-ok';
    }
  }

  errorBannerClose?.addEventListener('click', clearError);

  if (btnReconnect) {
    btnReconnect.addEventListener('click', () => {
      btnReconnect.textContent = 'Connecting...';
      chrome.runtime.sendMessage({ type: 'RECONNECT_BACKEND' }, () => {
        setTimeout(() => {
          btnReconnect.textContent = '🔄 Reconnect';
          refreshStatus();
          runDiagnostics();
        }, 800);
      });
    });
  }

  const chkMute = document.getElementById('chk-mute');
  const chkSubtitles = document.getElementById('chk-subtitles');

  const elDelayVal = document.getElementById('delay-val');
  const delayButtons = document.querySelectorAll('.btn-delay');

  let currentTabId = null;
  let currentDelay = 0;

  // 1. Detect current active tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs.length > 0) {
      const tab = tabs[0];
      currentTabId = tab.id;
      const url = tab.url || '';
      if (url.includes('youtube.com')) {
        elValTarget.textContent = 'YouTube';
        elValTarget.className = 'value text-rose';
      } else if (url.startsWith('http')) {
        try {
          const domain = new URL(url).hostname.replace('www.', '');
          elValTarget.textContent = domain.slice(0, 16);
          elValTarget.className = 'value text-sky';
        } catch {
          elValTarget.textContent = 'Other Web';
          elValTarget.className = 'value text-sky';
        }
      } else {
        elValTarget.textContent = 'Internal Tab';
        elValTarget.className = 'value text-slate';
      }
    }
  });

  // 2. Fetch initial status from background
  function refreshStatus() {
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => {
      if (chrome.runtime.lastError || !res) {
        setBackendStatus(false);
        return;
      }
      applyStatus(res);
    });
  }

  // 3. Listen for status updates from background
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'POPUP_STATUS_UPDATE' && message.status) {
      applyStatus(message.status);
    }
  });

  function setBackendStatus(connected) {
    if (connected) {
      elBackendBadge.className = 'badge badge-connected';
      elBackendStatusText.textContent = 'متصل';
      elValBackend.textContent = 'Connected';
      elValBackend.className = 'value text-emerald';
    } else {
      elBackendBadge.className = 'badge badge-disconnected';
      elBackendStatusText.textContent = 'غير متصل';
      elValBackend.textContent = 'Disconnected';
      elValBackend.className = 'value text-rose';
    }
  }

  function applyStatus(s) {
    // Backend connection
    setBackendStatus(s.wsConnected);

    // Browser status
    if (s.piStatus === 'ready' || s.state === 'dubbing') {
      elValBrowser.textContent = 'Connected';
      elValBrowser.className = 'value text-emerald';
    } else if (s.piStatus === 'loading') {
      elValBrowser.textContent = 'Loading...';
      elValBrowser.className = 'value text-amber';
    } else {
      elValBrowser.textContent = 'Ready';
      elValBrowser.className = 'value text-emerald';
    }

    // Capture status
    if (s.audioCaptureActive) {
      elValCapture.textContent = 'ON';
      elValCapture.className = 'value text-emerald font-bold';
    } else {
      elValCapture.textContent = 'OFF';
      elValCapture.className = 'value text-slate';
    }

    // STT status
    if (s.sttStatus === 'processing') {
      elValStt.textContent = 'Detecting...';
      elValStt.className = 'value text-amber animate-pulse';
    } else {
      elValStt.textContent = s.sttStatus || 'Idle';
      elValStt.className = 'value text-slate';
    }

    // Translation status
    if (s.translationStatus === 'processing') {
      elValTranslation.textContent = 'Translating...';
      elValTranslation.className = 'value text-amber animate-pulse';
    } else if (s.translationStatus === 'ready') {
      elValTranslation.textContent = 'Active';
      elValTranslation.className = 'value text-emerald';
    } else {
      elValTranslation.textContent = 'Idle';
      elValTranslation.className = 'value text-slate';
    }

    // Pi Voice status
    if (s.voiceStatus === 'fetching') {
      elValVoice.textContent = 'Preparing';
      elValVoice.className = 'value text-amber animate-pulse';
    } else if (s.voiceStatus === 'ready') {
      elValVoice.textContent = 'Ready';
      elValVoice.className = 'value text-emerald';
    } else {
      elValVoice.textContent = 'Idle';
      elValVoice.className = 'value text-slate';
    }

    // Latency
    if (s.latencySec) {
      elValLatency.textContent = `${s.latencySec} sec`;
    }

    // Buttons state
    const isDubbing = s.state === 'dubbing';
    const isPaused = s.state === 'paused';

    btnStart.disabled = isDubbing;
    btnStop.disabled = !isDubbing && !isPaused;
    btnPause.disabled = !isDubbing;
    btnResume.disabled = !isPaused;

    // Live texts
    if (s.currentSegment) {
      elSegmentBadge.textContent = `مقطع #${s.currentSegment}`;
    }
    if (s.lastSourceText) {
      elLiveSourceText.textContent = s.lastSourceText;
    }
    if (s.lastArabicText) {
      elLiveArabicText.textContent = s.lastArabicText;
    }

    // Checkboxes
    if (s.muteOriginal !== undefined) {
      chkMute.checked = Boolean(s.muteOriginal);
    }
    if (s.showSubtitle !== undefined) {
      chkSubtitles.checked = Boolean(s.showSubtitle);
    }

    // Delay
    if (s.audioDelayMs !== undefined) {
      currentDelay = s.audioDelayMs;
      elDelayVal.textContent = `${currentDelay}ms`;
      delayButtons.forEach(btn => {
        const d = Number(btn.getAttribute('data-delay'));
        if (d === currentDelay) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });
    }
  }

  function runDiagnostics() {
    if (diagExt) {
      diagExt.textContent = 'Loaded';
      diagExt.className = 'diag-val text-emerald';
    }
    if (diagManifest) {
      diagManifest.textContent = 'OK (V3)';
      diagManifest.className = 'diag-val text-emerald';
    }
    if (diagPopup) {
      diagPopup.textContent = 'OK';
      diagPopup.className = 'diag-val text-emerald';
    }
    if (diagOffscreen) {
      diagOffscreen.textContent = 'Ready';
      diagOffscreen.className = 'diag-val text-emerald';
    }

    // Ping Service Worker
    chrome.runtime.sendMessage({ type: 'PING' }, (res) => {
      if (chrome.runtime.lastError || !res) {
        if (diagSw) {
          diagSw.textContent = 'Starting...';
          diagSw.className = 'diag-val text-amber';
        }
      } else {
        if (diagSw) {
          diagSw.textContent = 'Running';
          diagSw.className = 'diag-val text-emerald';
        }
      }
    });

    // Check Backend
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => {
      if (res) {
        if (diagBackend) {
          diagBackend.textContent = res.wsConnected ? 'Connected' : 'Disconnected';
          diagBackend.className = res.wsConnected ? 'diag-val text-emerald' : 'diag-val text-rose';
        }
        if (diagCapture) {
          diagCapture.textContent = res.audioCaptureActive ? 'Active' : 'Ready';
          diagCapture.className = res.audioCaptureActive ? 'diag-val text-emerald font-bold' : 'diag-val text-sky';
        }
      }
    });

    // Ping Content Script
    if (currentTabId) {
      chrome.tabs.sendMessage(currentTabId, { type: 'PING' }, (res) => {
        if (chrome.runtime.lastError || !res) {
          if (diagContent) {
            diagContent.textContent = 'Standby';
            diagContent.className = 'diag-val text-slate';
          }
        } else {
          if (diagContent) {
            diagContent.textContent = res.isYouTube ? 'Loaded (YouTube)' : 'Loaded (Web)';
            diagContent.className = 'diag-val text-emerald';
          }
        }
      });
    }
  }

  // Button actions
  btnStart.addEventListener('click', () => {
    btnStart.disabled = true;
    clearError();
    chrome.runtime.sendMessage({
      type: 'START_DUBBING',
      tabId: currentTabId
    }, (res) => {
      btnStart.disabled = false;
      if (chrome.runtime.lastError) {
        showError(chrome.runtime.lastError.message);
      } else if (res && !res.success) {
        showError(res.error || 'فشل بدء الدبلجة');
      }
      refreshStatus();
      runDiagnostics();
    });
  });

  btnStop.addEventListener('click', () => {
    btnStop.disabled = true;
    chrome.runtime.sendMessage({
      type: 'STOP_DUBBING'
    }, (res) => {
      refreshStatus();
    });
  });

  btnPause.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'TOGGLE_PAUSE' }, () => {
      refreshStatus();
    });
  });

  btnResume.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'TOGGLE_PAUSE' }, () => {
      refreshStatus();
    });
  });

  chkMute.addEventListener('change', (e) => {
    chrome.runtime.sendMessage({
      type: 'SET_MUTE_ORIGINAL',
      muted: e.target.checked
    });
  });

  chkSubtitles.addEventListener('change', (e) => {
    chrome.runtime.sendMessage({
      type: 'SET_SUBTITLE_VISIBILITY',
      visible: e.target.checked
    });
  });

  const inputBackendUrl = document.getElementById('input-backend-url');
  const btnSaveBackendUrl = document.getElementById('btn-save-backend-url');
  const linkDashboard = document.getElementById('link-dashboard');

  // Load configured backend URL
  chrome.runtime.sendMessage({ type: 'GET_BACKEND_URL' }, (res) => {
    if (res && res.backendHttpUrl) {
      if (inputBackendUrl) inputBackendUrl.value = res.backendHttpUrl;
      if (linkDashboard) linkDashboard.href = res.backendHttpUrl;
    }
  });

  if (btnSaveBackendUrl && inputBackendUrl) {
    btnSaveBackendUrl.addEventListener('click', () => {
      const val = inputBackendUrl.value.trim();
      if (!val) return;
      btnSaveBackendUrl.textContent = 'جاري الحفظ...';
      chrome.runtime.sendMessage({ type: 'SET_BACKEND_URL', url: val }, (res) => {
        btnSaveBackendUrl.textContent = 'تم الحفظ!';
        setTimeout(() => { btnSaveBackendUrl.textContent = 'تطبيق والاتصال'; }, 1500);
        if (linkDashboard) linkDashboard.href = val;
        refreshStatus();
      });
    });
  }

  delayButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const delay = Number(btn.getAttribute('data-delay'));
      currentDelay = delay;
      elDelayVal.textContent = `${delay}ms`;
      delayButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      chrome.runtime.sendMessage({
        type: 'SET_AUDIO_DELAY',
        delayMs: delay
      });
    });
  });

  // Initial poll and recurring poll every 1.5s
  refreshStatus();
  runDiagnostics();
  setInterval(() => {
    refreshStatus();
    runDiagnostics();
  }, 1500);
});
